import React from 'react'
import {Link} from 'react-router-dom'
function DirectMessage() {
  return (
    <div>
        Direct Message
        <div>
            <Link to='/MessagePage' >back</Link>
        </div>
      
    </div>
  )
}

export default DirectMessage
