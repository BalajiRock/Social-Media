const FriendsList=[
    {
        UserID:"Noiceee madu"
    },
    {
        UserID:"Yash"
    },
    {
        UserID:"Raj"
    }
    ,{
        UserID:"Rohan"
    },
    {
        UserID:"Puneet"
    
    },
    {
        UserID:"Vivek"
    },
    {
        UserID:"Aman"
    },
    ]
    export default FriendsList;
    