const Posts=[
    {
        comments:"Noiceee madu",
        likes:"123"
    },
    {
        comments:"Yash",
        likes:"124"
    },
    {
        comments:"Raj",
        likes:"125"
    },{
        comments:"Rohan",
        likes:"126"
    },
    {
        comments:"Puneet",
        likes:"127"
    
    },
    {
        comments:"Vivek",
        likes:"128"
    },
    {
        comments:"Aman",
        likes:"129"
    },
    ]
    export default Posts;
    